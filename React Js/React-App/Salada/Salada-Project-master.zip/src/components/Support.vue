<template>
<div class="support_bg">
<div class="container">  
<div class="row">
<div class="customer_style">    
        <h1>  Customer <br> <span class="txt_style"> Support </span> </h1>
</div>
<div class="row support">
<div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-sm-12">
    
    <img class="support_style" alt="Tools Background" src="/assets/Support.png">
    
</div>
 
<div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-sm-12">
<div class="support_design"> 
<h3 class=""> Any Query? <span class="small_txt"> Call us at: +92333-215678 </span>  </h3> <p class=""> This is Lorem Ipsum and we are not availeble for these kind of things we must be on for the big organisations we used for kind of things we consider for. </p>
<p class=""> The text is upto the scheme and you want to be the next next scheme for always been positive for considerablle </p>
<button type="submit" class="btn_style mt-4" aria-label="Submit Button"> Get Started <span class="icon_style"> <i class="fa fa-angle-right"></i> </span></button>
</div>
</div>
</div>
</div>
</div>
</div>
       
</template>

<script>
export default {
    name: "Support",
};
</script>


<style scoped>

.customer_style
{
padding-top: 35px;
margin-bottom: 15px;
}

.support
{

padding-bottom: 100px;

}

.text
{

color:  #E6FFFC;

}

.support_bg
{
/* background-color: #378475; */
}

.support_design
{
 padding-top: 45px;
 text-align: left;

}

.small_txt
{
    font-size: medium;
    padding-left: 7px;
}

.icon_style
{
   padding-left: 20px;
}

 .btn_style
  {
    background-color: transparent;
    border-radius: 5px;
    padding: 5px;
    display: inline-block;
    padding-left: 20px;
  }

.txt_style
{
    font-weight: bolder;
}

.icon_style
{
   padding-left: 15px;
}

.support_style
{

height: 300px;
/* padding-left: 340px; */
/* padding-top: 50px; */

}

button:hover
{
  background-color: #1F4F46;
  box-shadow: 4px 2px 3px rgb(161, 161, 161);
  color: white;
}
.support_style:hover
{
    box-shadow: 10px 2px 10p black;
}

.style
{
   margin-top: 1px; 
}



@media (min-width:1200px) and (max-width: 2000px) 
{


}

@media (min-width:992px) and (max-width: 1199px) 
{


}

@media (min-width:768px) and (max-width: 991px) 
{



}


@media (min-width:576px) and (max-width: 767px) 
{

}


@media (min-width:320px) and (max-width: 575px) 
{



  
}

</style>