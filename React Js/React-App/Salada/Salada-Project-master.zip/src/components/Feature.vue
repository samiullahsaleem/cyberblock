<template>
            <div class="feature_style">    
            <div class="container">
            <div class="row"> 

            <div class="col-lg-12 col-md-12">
            <h1>
                Checkout Our <span class="txt_style"> Software </span> <br> Features Below
            </h1>
            </div>

            <div class="card_style">
            <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="card style">
                <div class="p-5 enroll2">
                <div class="row text-center">
                <div class="col-lg-12 ">
                <div class="icon_box">
                        <img src="assets/Group 1761.png">
                </div>
                </div>

                </div>
                    <div class="row text-center">
                    <div class="col-lg-12">
                        <h5> Lorem Ipsum Lorem </h5>
                        <p>
                            Description is like something we need for.
                        </p>
                        <a href="" class="arrow-styl"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                    </div>
                    </div>
                </div>
            </div>  
            </div>
                        
            <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="card style">
                <div class="p-5 enroll2">
                <div class="row text-center">
                <div class="col-lg-12 ">
                        <div class="icon_box">
                <div>
                        <img src="assets/Group 1762.png">
                </div>
                </div>
                </div>

                </div>
                    <div class="row text-center">
                    <div class="col-lg-12">
                        <h5> Lorem Ipsum Lorem </h5>
                        <p>
                            Description is like something we need for.
                        </p>
                        <a href="" class="arrow-styl"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                    </div>
                    </div>
                </div>
            </div>  
            </div>

            <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="card style">
                <div class="p-5 enroll2">
                <div class="row text-center">
                <div class="col-lg-12 ">
                    <div class="icon_box">
                <div>
                        <img src="assets/Group 1763.png">
                </div>
                </div>
                </div>

                </div>
                    <div class="row text-center">
                    <div class="col-lg-12">
                        <h5> Lorem Ipsum Lorem </h5>
                        <p>
                            Description is like something we need for.
                        </p>
                        <a href="" class="arrow-styl"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                    </div>
                    </div>
                </div>
            </div>  
            </div>

            <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="card style">
                <div class="p-5 enroll2">
                <div class="row text-center">
                <div class="col-lg-12 ">
                    <div class="icon_box">
                <div>
                        <img src="assets/Group 1764.png">
                </div>
                </div>
                </div>

                </div>
                    <div class="row text-center">
                    <div class="col-lg-12">
                        <h5> Lorem Ipsum Lorem </h5>
                        <p>
                            Description is like something we need for.
                        </p>
                        <a href="" class="arrow-styl"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                    </div>
                    </div>
                </div>
            </div>  
            </div>

            </div>
            </div>

            </div>

            </div>
            </div>
</template>

<script>
export default {
    name: "Feature"
};
</script>


<style scoped>

.feature_style
{ 
   padding-top: 80px;
   padding-bottom: 80px;
   background-color: whitesmoke;
}


.card_style
{

margin-top: 70px;
 border: 5px solid transparent;

}
.card{
    border: 0;
}
.style
{
    padding: 40px;
    border-radius: 8px;    
}

.icon_box
{
 border: 1px solid transparent;
 border-radius: 8px;
 background-color: #E6FFFC;
 padding: 50px;
 margin-bottom: 50px;
}


.icon_box img 
{
    width: 66px;
    height: 66px;
}

/* .card:hover .icon_box
{
  box-shadow: 0px 10px 15px -5px rgb(182, 182, 182);
} */

.card:hover
{
  box-shadow: 0px 4px 15px -1px rgb(182, 182, 182);
  border: 0;
} 



.txt_style
{

font-weight: bolder;

}
.arrow-styl i{
    color: black;
    font-size: 22px;
     transition: all 0.5s;
}
.arrow-styl:hover i{
    transform: scale(1.5);
    transition: all 0.5s;
}
@media (min-width:1200px) and (max-width: 2000px) 
{


}

@media (min-width:992px) and (max-width: 1199px) 
{
.style
{
    padding: 0px !important;
    border-radius: 8px;
    
}

}

@media (min-width:768px) and (max-width: 991px) 
{



}


@media (min-width:576px) and (max-width: 767px) 
{

}


@media (min-width:320px) and (max-width: 575px) 
{



  
}


</style>