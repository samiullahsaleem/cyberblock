<template>


<div class="container-fluid">
<div class="row">
 
   <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-sm-12">
      
           <img class="tool_image" alt="Tools Background" src="/assets/42.png">
       
    </div>


    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-sm-12"> 
    <div class="tool_section">
        <h1>
           Powerful <span class="txt_style"> Tools </span> for Your <br> Customers
       </h1>
        <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.  Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
          <ul class="list_style">
          <p> <i class="fa fa-check" aria-hidden="true"> </i> This is Salada for BitsClan. we take Orders </p> 
          <p> <i class="fa fa-check" aria-hidden="true"> </i> This is Salada for BitsClan. We have complete application </p> 
          <p> <i class="fa fa-check" aria-hidden="true"> </i> This is Salada for BitsClan. Integrate into some things we do together</p>    
          <button type="submit" class="btn_style mt-4" aria-label="Submit Button"> Free Trial <span class="icon_style"> <i class="fa fa-angle-right"></i> </span></button>        
          </ul>
                    
      </div>
 

        </div>
     </div>
   
</div>


    
</template>


<script>
export default 
{
   name: "Videos"    
};

</script>

<style scoped>


.tool_image
{

height: 100vh;
widows: auto;
background-repeat: no-repeat;
background-position: center;
background-size: cover; 
 
}


.tool_section
{
   text-align: left;
   padding-top: 130px;
   padding-bottom: 200px;
   background-repeat: no-repeat;
   background-position: center;
   background-size: cover;    
}

.list_style
{
  margin-top: 50px;
}

 

.icon_style
{
   padding-left: 20px;
}


.txt_style
{

font-weight: bolder;

}


button:hover
{
  background-color: #1F4F46;
  box-shadow: 4px 2px 3px rgb(161, 161, 161);
  color: white;
}

 .btn_style
  {
    background-color: transparent;
    border-radius: 5px;
    padding: 5px;
    display: inline-block;
    padding-left: 20px;
  }

ol, ul {
    padding-left: 0rem !important;
}


@media (min-width:1200px) and (max-width: 2000px) 
{


}

@media (min-width:992px) and (max-width: 1199px) 
{


}

@media (min-width:768px) and (max-width: 991px) 
{



}


@media (min-width:576px) and (max-width: 767px) 
{

}


@media (min-width:320px) and (max-width: 575px) 
{



  
}

</style>