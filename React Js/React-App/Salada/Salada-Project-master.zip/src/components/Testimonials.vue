<template>    
<section class="testimonial_bg">
<div class="container">
<div class="test_bg">

    <div class="row">
    <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-16">    
    <h1> Checkout Our <br> <span class="txt_style"> Testimonials </span> </h1>
    </div>
    </div>

    <div class="row testi_style">
        <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-12 col-sm-12">
           <div class="card">                        
                        <div class="card_img"> </div>
                        <div class="card-body">
                          <h6 class="card-title"> This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. </h6>
                          
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                 <div class="row">
                            <div class="col-lg-4">
                                <img src="assets/img-person2.png">
                            </div>
                            <div class="col-lg-8">
                                <h6> Penny Tiler </h6>
                                <small>  Added on 29 September 2018 </small>
                            </div>                            
                                </div>
                                </div>
                        </div>
                        
</div>
        </div>

        <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-12 col-sm-12">
<div class="card">                        
                        <div class="card_img">  </div>
                        <div class="card-body">
                          <h6 class="card-title"> This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. </h6>
                          
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                <div class="row">
                            <div class="col-lg-4">
                                <img src="assets/img-person3.png">
                            </div>
                            <div class="col-lg-8">
                                <h6> Penny Tiler </h6>
                                <small>  Added on 29 September 2018 </small>
                            </div>                            
                                </div>
                                </div>
                        </div>
                        
</div>
        </div>

        <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-12 col-sm-12">
<div class="card">                        
                        <div class="card_img"> </div>
                        <div class="card-body">
                         <h6 class="card-title"> This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. </h6>
                          
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                <div class="row">
                            <div class="col-lg-4">
                                <img src="assets/img-person4.png">
                            </div>
                            <div class="col-lg-8">
                                <h6> Penny Tiler </h6>
                                <small>  Added on 29 September 2018 </small>
                            </div>                            
                                </div>
                                </div>
                        </div>
                        
</div>
         </div>

         <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-12 col-sm-12">
         <div class="card">                        
                        <div class="card_img">  </div>
                        <div class="card-body">
                          <h6 class="card-title"> This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. </h6>
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                <div class="row">
                            <div class="col-lg-4">
                                <img src="assets/img-person1.png">
                            </div>
                            <div class="col-lg-8">
                                <h6> Penny Tiler </h6>
                                <small>  Added on 29 September 2018 </small>
                            </div>                            
                                </div>
                                </div>
                             </div>
                        
</div>
         </div>
    </div>

    </div>
</div>

  

</section>
</template>

<script>
export default {
    name: 'Testimonials',    
};

</script>

<style scoped>

.testimonial_bg
{
    background-color: #E6FFFC;
    padding-bottom: 50px;
}

.test_bg
{
padding-top: 45px;
}

.txt_style
{
font-weight: bolder;
}

.card-title
{
text-align: justify;
}

.testi_style
{
padding-top: 50px;
}


@media (min-width:1200px) and (max-width: 2000px) 
{


}

@media (min-width:992px) and (max-width: 1199px) 
{

.card
{
    margin-bottom: 30px;
}

}

@media (min-width:768px) and (max-width: 991px) 
{

.card {
    margin-bottom: 30px;

}
}


@media (min-width:576px) and (max-width: 767px) 
{

}


@media (min-width:320px) and (max-width: 575px) 
{



  
}

</style>