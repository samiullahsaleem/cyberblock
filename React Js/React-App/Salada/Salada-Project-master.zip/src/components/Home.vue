<template>
  <div>
    <h1> Salada Project </h1>
    <!-- <h2>{{ data }}</h2> -->
  </div>
</template>


<script>
export default {
  name: "Home",
  props: {
    data: String,
  },
};
</script>