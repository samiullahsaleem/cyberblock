<template>
<div class="container">
<div class="row">
<div class="article_style">
 <h1 class="art_txt">  Checkout Our Latest <br> News & Articles </h1>
</div>

</div>
<div class="card_style"> 
<div class="row">  
<div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-12">
<div class="card">                        
                        <div class="card_img"> <img src="/assets/Salad1.png"> </div>
                        <div class="card-body">
                          <h4 class="card-title"> Language Learning </h4>
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                <div class="row pill_Style">                               
                                <div class="col-lg-7">
                                    <div class="row">
                                    <div class="profile">                                    
                                    </div>                       
                                    <h6 class="profile_text"> <i class="fa fa-eye"> 123 </i> &nbsp; &nbsp; &nbsp; &nbsp; <i class="fa fa-comment"> 124 </i> </h6>
                                    </div>  
                                </div>
                                <div class="col-lg-5">
                                   <div class="pill"> Read More </div>
                                </div>
                                </div>
                                </div>
                        </div>
                        
</div>
</div>

<div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-12">
                    <div class="card">                        
                        <div class="card_img"> <img src="/assets/Salad4.png"> </div>
                        <div class="card-body">
                          <h4 class="card-title"> Language Learning </h4>
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                <div class="row pill_Style">                               
                                <div class="col-lg-7">
                                    <div class="row">
                                    <div class="profile">                                    
                                    </div>                       
                                    <h6 class="profile_text"> <i class="fa fa-eye"> 12 </i>  &nbsp; &nbsp; &nbsp; &nbsp; <i class="fa fa-comment"> 12 </i> </h6>
                                    </div>  
                                </div>
                                <div class="col-lg-5">
                                   <div class="pill"> Read More </div>
                                </div>
                                </div>
                                </div>
                        </div>
                        
                    </div>
</div>

<div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-12">
                    <div class="card">                        
                        <div class="card_img"> <img src="/assets/Salad3.png"> </div>
                        <div class="card-body">
                          <h4 class="card-title"> Language Learning </h4>
                          <hr>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        </div>
                        <div class="card-footer">
                            <div class="container">
                                <div class="row pill_Style">                               
                                <div class="col-lg-7">
                                    <div class="row">
                                    <div class="profile">                                    
                                    </div>                       
                                    <h6 class="profile_text"><i class="fa fa-eye"> 12 </i>   &nbsp; &nbsp; &nbsp; &nbsp;  <i class="fa fa-comment"> 12 </i> </h6>
                                    </div>  
                                </div>
                                <div class="col-lg-5">
                                   <div class="pill"> Read More </div>
                                </div>
                                </div>
                                </div>
                        </div>
                        
                    </div>
</div>



</div>
</div>
</div>
</template>

<script>
export default  {
    name: 'Article',
};
</script>

<style scoped>


.article_style
{
padding-top: 50px;
}


.card_style
{
padding-top: 0px;
padding: 50px;
margin: 5px;
}


img, svg {
    vertical-align: middle;
    max-width: 100%;
}

@media (min-width:1200px) and (max-width: 2000px) 
{


}

@media (min-width:992px) and (max-width: 1199px) 
{


}

@media (min-width:768px) and (max-width: 991px) 
{



}


@media (min-width:576px) and (max-width: 767px) 
{

}


@media (min-width:320px) and (max-width: 575px) 
{



  
}


</style>