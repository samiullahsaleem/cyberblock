This is the project based on OTP system and online payment management system.
This project is submitted according to the requirements of administrations.

-> To run the product start compilation from MainClass.java file.
-> Database has all the data stored.
-> Controller file contains packaged other runable files.


Thank you
Tayyab Nasir
218-BSCS-2019 (E2)