import controller.*;

import java.util.Scanner;
import java.util.*;
public class MainClass
{

    public static void main(String args[])
    {
         String Check;
        int M1;
        Scanner t= new Scanner(System.in);
        
        Bank bank = new Bank("MCB", 2055, 634743874, 289, 25278564, "1/12/2020", 20);
    	bank.ignite();
    	bank.enterDetail("Alfalah", 6767, 458873942, 344, 98675552, "24/3/2020");
    	bank.enterDetail("Meezan", 4356, 18963942, 634, 47895552, "7/6/2020");
        bank.enterDetail("UBL", 7658, 5987942, 834, 19837552, "19/2/2020");
        bank.addAmount(25);
        bank.addAmount(1023);
        bank.addAmount(68);

        System.out.println("\nEnter Y for generate otp automatically");
        Check=t.nextLine();
        if (Check.equals("Y"))
         {
             bank.OtpSol();
         }
         else
         {
             System.out.println("You entered the wrong value");
         }
         System.out.println("\nEnter 1 for adding amount\n Enter 2 for display all otp\n Enter 3 for get Total Amount\n Enter 4 to display all amounts");
         System.out.println("\nEnter 5 for Search Otp\n Enter 6 for Search amount\n Enter 7 for remove set\n Enter 8 for Display OTP with Amount");
         System.out.println("\nEnter 9 for Display all details");
         M1=t.nextInt();
         if (M1==1)
        {
             System.out.println("\nEnter amount");
            int a=t.nextInt();
            bank.addAmount(a);
        }
         else if (M1==2)
         {
             bank.displayOTP();
         }
         else if (M1==3)
         {
             bank.getTotalAmount();
         }
         else if (M1==4)
         {
             bank.displayAmounts();
         }
        else if (M1==5)
         {
             System.out.println("Enter Otp which you want to chek");
            int b=t.nextInt();
             bank.searchOtp(b);
         }
         else if (M1==6)
         {
             System.out.println("Enter Amount which you want to chek");
             int c=t.nextInt();
            bank.searchAmount(c);
            }
         else if (M1==7)
         {
             System.out.println("Enter Account number to remove payment method");
             int d=t.nextInt();
             bank.removeSet(d);
         }
         else if (M1==8)
         {
             bank.Display();
         }
         else if (M1==9)
         {
             bank.DisplayAll();
         }
         else
         {
             System.out.println("\nYou entered wrong number");
         }

        Product C= new Product();
         C.initial();

         try{
         C.addProduct();
         }
         catch (Exception e)
         {}

        System.out.println("\nEnter 1 for Client service \nEnter 2 for Product service");
        int e=t.nextInt();
        if (e==1)
        {
            System.out.println("\nEnter 1 to find name in data \nEnter 2 to find Cnic in data \nEnter 3 to have specific details \nEnter 4 to view all members");
            int f=t.nextInt();
            if (f==1)
            {
                C.Name_conf();
            }
            else if (f==2)
            {
                C.cnic_conf();
            }
            else if (f==3)
            {
                C.Specific_detail();
            }
            else if (f==4)
            {
                C.viewAllMember();
            }
            else
            {
                System.out.println("\nYou entered the wrng value for the selection of Client menu");
            }

        }
        else if (e==2)
        {
            System.out.println("\nEnter 1 for view product details \nEnter 2 for search product details");
            int g=t.nextInt();
            if (g==1)
            {
                try{
                C.viewProduct(); } catch (Exception f) {}
            }
            else if (g==2)
            {
                try{
                C.searchProduct(); } catch (Exception x) {}
            }
            else
            {
                System.out.println("You entered wrong value for selecting product menu");
            }

        }
        else 
        {
            System.out.println("\nYou entered the wrong value");
        }

        
    }
}