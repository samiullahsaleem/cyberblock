/*                 OTP service : Solutions
				   Tayyab Nasir
				   218-BSCS-2019
				   Section E2

				   There you will get to know about the banking scenarios
				   The classes include (Bank.java) (Otp.java) (Client.java) (Product.java) (MainClass.java) 
*/
package controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.*;
public class Bank extends Otp
{
	public String bName;
	public int bCode,e,p;
	public double accountNumber;
	public int cvv;
	public double cardNumber;
	public String expDate;
	Scanner scan = new Scanner(System.in);
	ArrayList <String> n = new ArrayList <String>();
	ArrayList <Integer> c = new ArrayList <Integer>();
	ArrayList <Double> an = new ArrayList <Double>();
	ArrayList <Integer> cv = new ArrayList <Integer>();
	ArrayList <Double> cn = new ArrayList <Double>();
	ArrayList <String> ed = new ArrayList <String>();
    HashMap <String, Double> H1 = new HashMap <String, Double>();
    HashMap <Integer, Double> H2 = new HashMap <Integer, Double>();
    
	public Bank(String bName, int bCode, double accountNumber, int cvv, double cardNumber, String expDate, int amount)
	{
		super(amount);
		this.bName=bName;
		this.bCode=bCode;
		this.accountNumber= accountNumber;
		this.cvv=cvv;
		this.cardNumber=cardNumber;
		this.expDate=expDate;
		n.add(bName);
		c.add(bCode);
		an.add(accountNumber);
		cv.add(cvv);
		cn.add(cardNumber);
		ed.add(expDate);
		H1.put(bName, accountNumber);
		H2.put(bCode, cardNumber);

	}
	public void ignite()
	{
		System.out.println("\nEnter the name of bank");
        bName = scan.nextLine();
        System.out.println("\nEnter the bank code");
		bCode=scan.nextInt();
		System.out.print("\nEnter the Acc No");
		accountNumber = scan.nextDouble();
		System.out.print("\nEnter CVV No.");
		cvv=scan.nextInt();
		System.out.print("\nEnter Card No");
		cardNumber= scan.nextDouble();
		System.out.print("\nEnter the Exp Date in the format dd/mm/yyyy");
		expDate=scan.nextLine();
		n.add(bName);
		c.add(bCode);
		an.add(accountNumber);
		cv.add(cvv);
		cn.add(cardNumber);
		ed.add(expDate);
		H1.put(bName, accountNumber);
		H2.put(bCode, cardNumber);

	}

	public String getbName() 
	{
		return bName;
	}
	public void setbName(String bName) 
	{
		this.bName = bName;
	}
	public int getbCode() 
	{
		return bCode;
	}
	public void setbCode(int bCode) 
	{
		this.bCode = bCode;
	}
	public double getAccountNumber() 
	{
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) 
	{
		this.accountNumber = accountNumber;
	}
	public int getCvv() 
	{
		return cvv;
	}
	public void setCvv(int cvv) 
	{
		this.cvv = cvv;
	}
	public double getCardNumber() 
	{
		return cardNumber;
	}
	public void setCardNumber(int cardNumber) 
	{
		this.cardNumber = cardNumber;
	}
	public String getExpDate() 
	{
		return expDate;
	}
	public void setExpDate(String expDate) 
	{
		this.expDate = expDate;
	}
	public void enterDetail(String bName, int bCode, double accountNumber, int cvv, double cardNumber, String expDate) {
		n.add(bName);
		c.add(bCode);
		an.add(accountNumber);
		cv.add(cvv);
		cn.add(cardNumber);
		ed.add(expDate);
		H1.put(bName, accountNumber);
		H2.put(bCode, cardNumber);
	}
	public void DuplicateBname()
	{	
	String key="Key";
		double value=0;
		for (Map.Entry <String,Double> mapElement : H1.entrySet()) 
		{ 
			int y=0;
			
			value = mapElement.getValue();
			key= mapElement.getKey();
			for (Map.Entry <String,Double> mapElement1 : H1.entrySet())
			{
				double v = mapElement1.getValue();
				String k= mapElement1.getKey();
				if (v == value)
				{
					y++;
					if (y>1)
					{
						System.out.println("The duplicate value of key "+key);
						break;
					}
				}
				
			}		
		}
		
	}
	public void getAccNoH1(String n)
	{
		for(String a:H1.keySet())
		{
			if(a.equals(n))
			{
				System.out.println("The account number of bank "+ a +" is =  "+H1.get(a));
			}
		}
	}
	public void getBcodeH2(double d)
	{
		for (Map.Entry <Integer, Double> mapE : H2.entrySet())
		{
			int ky = mapE.getKey();
			double val = mapE.getValue();
			if (val==d)
			{
				System.out.println("The bank code (key) = "+ ky +"of account number "+mapE.getValue());
			}
		}
	}
	public void findOtp_AcNo(double e)
	{
		for (double f: an)
		{
			if (f==e)
			{
				int ch=an.indexOf(f);
				for (int i=0; i<an.size(); i++)
				{
					if (i==ch)
					{
						e = O.get(i);
						System.out.println("The otp of account no "+f+"is = "+e);
					}
				}
			}
		}
	}
	public void findOtp_CardNo(double g)
	{
		for (double x: cn)
		{
			if (x==g)
			{
				int ch=an.indexOf(x);
				for (int j=0; j<an.size(); j++)
				{
					if (j==ch)
					{
						p = O.get(j);
						System.out.println("The otp of Card Number "+x+"is = "+p);
					}
				}
			}
		}
	}
	public void removeElements(String bName, int bCode, double accountNumber, int cvv, double cardNumber, String expDate)
	{
		Iterator it = n.iterator();
		while(it.hasNext())
		{
			String A = (String)it.next();
			if (A.contains(bName))
			{
				it.remove();
			}
		}
		Iterator it1 = c.iterator();
		while(it1.hasNext())
		{
			int B = (Integer)it1.next();
			if (B==(bCode))
			{
				it1.remove();
			}
		}
		Iterator it2 = an.iterator();
		while(it2.hasNext())
		{
			double C = (Double)it2.next();
			if (C==(accountNumber))
			{
				it2.remove();
			}
		}
		Iterator it3 = cv.iterator();
		while(it3.hasNext())
		{
			int D = (Integer)it3.next();
			if (D==(cvv))
			{
				it3.remove();
			}
		}
		Iterator it4 = cn.iterator();
		while(it4.hasNext())
		{
			double E = (Double)it4.next();
			if (E==(cardNumber))
			{
				it4.remove();
			}
		}
		Iterator it5 = ed.iterator();
		while(it5.hasNext())
		{
			String F = (String)it5.next();
			if (F.equals(expDate))
			{
				it5.remove();
			}
		}
		
	}
	public void removeSet(double accountNumber)
	{
		Iterator IT = an.iterator();
		while (IT.hasNext())
		{
			double check = (Double)IT.next();
			if (check==accountNumber)
			{
				int in = an.indexOf(check);
				an.remove(in);
				n.remove(in);
				c.remove(in);
				cn.remove(in);
				cv.remove(in);
				ed.remove(in);
			}
		}
	}
	public void Display()
	{

			System.out.println("Bank Name = "+n);
			System.out.println();
			System.out.println("Bank Code = "+c);
			System.out.println();
			System.out.println("Account Number = "+an);
			System.out.println();
			System.out.println("CVV = "+cv);
			System.out.println();
			System.out.println("Card Number = "+cn);
			System.out.println();
			System.out.println("Expiry Date of Card = "+ed);
			System.out.println();
		
		System.out.println("Hashmap 1 with bank name and account number "+H1);
		System.out.println();
		System.out.println("Hasmap 2 with Branch code and Card Number "+H2);
	}

}
	
	
	

	


