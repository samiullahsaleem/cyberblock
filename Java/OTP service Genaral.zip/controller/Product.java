/*                 OTP service : Solutions
				   Tayyab Nasir
				   218-BSCS-2019
				   Section E2

				   There you will get to know about the Product data management scenarios
				   The classes include (Bank.java) (Otp.java) (Client.java) (Product.java) (MainClass.java) 
*/
package controller;
import java.util.Scanner;
import java.io.*;
import java.util.*;
import java.io.File;

public class Product extends Client
{
	private  String itemName;
	private int itemID;
	private int itemPrice;
	private String checkName;
	private Boolean find=false;
	ArrayList<String> IN= new ArrayList<>();
	ArrayList<Integer> Id= new ArrayList<>();
	ArrayList<Integer> Pr= new ArrayList<>();
    Scanner scan= new Scanner(System.in);
    File pro = new File("Product.txt");
    
    public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemID() {
		return itemID;
	}

	public void setItemID(int itemID) {
		this.itemID = itemID;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public ArrayList<String> getIN() {
		return IN;
	}

	public void setIN(ArrayList<String> iN) {
		IN = iN;
	}

	public ArrayList<Integer> getId() {
		return Id;
	}

	public void setId(ArrayList<Integer> id) {
		Id = id;
	}

	public ArrayList<Integer> getPr() {
		return Pr;
	}

	public void setPr(ArrayList<Integer> pr) {
		Pr = pr;
	}
    public void addProduct() throws Exception
	{
		
		System.out.println("Write the product Name.");
		itemName=scan.nextLine();
		System.out.println("Write the product price.");
		itemPrice=scan.nextInt();
		System.out.println("Write code of product");
		itemID=scan.nextInt();
		IN.add(itemName);
		Id.add(itemID);
		Pr.add(itemPrice);
		FileWriter FW;

		try{
		FW = new FileWriter(pro,true);
		FW.write(itemName+","+itemPrice+","+itemID+"\n");
		FW.close();

		System.out.println("\n Item is stored !");
		}
		catch (Exception e)
		{
			System.out.println("Exceptional error");
		}
	}
    
	public void viewProduct() throws Exception

	{

		Scanner PRD = new Scanner(pro);

		while(PRD.hasNextLine())

		{
			String proLine = PRD.nextLine();
			String [] split = proLine.split(",");

			for (int i=0;i<proLine.length() ;i++ ) {
				
				if (i==0) {
					System.out.println("Grocery product Name :"+split[0]);
				}
				else if (i==1) {
					System.out.println("Grocery product Price :"+split[1]);
				}
				else if (i==2) {
					System.out.println("Grocery product Code :"+split[2]);
				}
			}
			System.out.println("\n_____________________________");
		} 
	
	}
	
	public void searchProduct() throws Exception

	{

		System.out.println("\nEnter Name of product which you want");
		checkName=scan.nextLine();

		Scanner SP = new Scanner(pro);

		while(SP.hasNextLine())

		{
			String PLine = SP.nextLine();
			String [] split = PLine.split(",");

			if (checkName.equals(split[0])) 
			{
				for (int g=0;g<PLine.length() ;g++ ) {
				//System.out.println(split[g]);

				if (g==0) {
					System.out.println("Grocery product Name :"+split[0]);
				}
				else if (g==1) {
					System.out.println("Grocery product Price :"+split[1]);
				}
				else if (g==2) {
					System.out.println("Grocery product Code :"+split[2]);
				}
				find=true;
				//System.out.println("\n\t\t\t______________________________");

			}

			
			}

		}

		if (find==true) 
		{
			System.out.println("Displayed the specific grossery");
		}
		else
		{
			System.out.println("\nThis Item is not Available Yet.");
		}
		SP.close(); 
	}
	


}
