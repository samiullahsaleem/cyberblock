/*                 OTP service : Solutions
				   Tayyab Nasir
				   218-BSCS-2019
				   Section E2

				   There you will get to know about the Client data management scenarios
				   The classes include (Bank.java) (Otp.java) (Client.java) (Product.java) (MainClass.java) 
*/
package controller;
import java.io.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class Client {

	private String cnic;
	private int age;
	private String city;
	private String name;
	boolean F = false;
	ArrayList <String> Cn = new  ArrayList<>();
	ArrayList <Integer> I = new  ArrayList<>();
	ArrayList <String> Ci = new  ArrayList<>();
	ArrayList <String> N = new  ArrayList<>();
	

	Scanner m = new Scanner(System.in);
	File fileCustomer = new File("Customer.txt");
	

	public String getCnic() {
		return cnic;
	}

	public void setCnic(String cnic) {
		this.cnic = cnic;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getCn() {
		return Cn;
	}

	public void setCn(ArrayList<String> cn) {
		Cn = cn;
	}

	public ArrayList<Integer> getI() {
		return I;
	}

	public void setI(ArrayList<Integer> i) {
		I = i;
	}

	public ArrayList<String> getCi() {
		return Ci;
	}

	public void setCi(ArrayList<String> ci) {
		Ci = ci;
	}

	public ArrayList<String> getN() {
		return N;
	}

	public void setN(ArrayList<String> n) {
		N = n;
	}

	public void initial()

	{

		System.out.print("Enter name : \n");
		name = m.nextLine();
		N.add(name);
		System.out.print("your CNIC number : \n");
		cnic = m.nextLine();
		Cn.add(cnic);
		System.out.print("Enter your Age : \n");
		age = Integer.parseInt(m.nextLine());
		I.add(age);
		System.out.print("Enter your City Name : \n");
		city = m.nextLine();
		Ci.add(city);

		FileWriter fileWriteCus;
		try {

			fileWriteCus = new FileWriter(fileCustomer, true);

			fileWriteCus.write(name + "," + cnic + "," + age + "," + city + "\n");
			fileWriteCus.close();
			System.out.println("\n data saved");

		}

		catch (Exception e) {
			System.out.println("Error Occured in initial");
		}

	}

	public void Name_conf()

	{

		try {

			System.out.print("Please Enter your name: \n");
			name = m.nextLine();

			Scanner fileReader = new Scanner(fileCustomer);

			while (fileReader.hasNextLine()) {
				String CL = fileReader.nextLine();
				String[] lineSep = CL.split(",");

				if (name.equals(lineSep[0])) {

					F = true;

				}
			}

			if (F == true) {
				System.out.println("\n Your name " + name + " is included in data");

			} else {
				System.out.println("\n Your name " + name + " is not included in data");
			}

		}

		catch (Exception e) {
			System.out.println("There is an error in customer class file Exception");
		}
	}

	public void cnic_conf()

	{

		try {

			System.out.print("Please Enter your cnic: \n");
			cnic = m.nextLine();

			Scanner fileReader = new Scanner(fileCustomer);

			while (fileReader.hasNextLine()) {
				String CL = fileReader.nextLine();
				String[] lineSep = CL.split(",");

				if (cnic.equals(lineSep[1])) {

					F = true;

				}
			}

			if (F == true) {
				System.out.println("\n Your cnic " + cnic + " is included in data");

			} else {
				System.out.println("\n Your cnic " + cnic + " is not included in data");
			}

		}

		catch (Exception e) {
			System.out.println("There is an error in customer class file Exception");
		}
	}

	public void Specific_detail()

	{
		try {

			System.out.print("Please Enter your cnic: \n");
			cnic = m.nextLine();

			Scanner fileReader = new Scanner(fileCustomer);

			while (fileReader.hasNextLine()) {
				String CL = fileReader.nextLine();
				String[] LS = CL.split(",");

				if (cnic.equals(LS[1])) {

					F = true;
					for (int c = 0; c < CL.length(); c++) {

						if (c == 0) {
							System.out.println("Your name is.");
							System.out.println(LS[0]);
						} else if (c == 1) {
							System.out.println("Your CNIC is.");
							System.out.println(LS[1]);
						} else if (c == 2) {
							System.out.println("Your AGE is.");
							System.out.println(LS[2]);
						} else if (c == 3) {
							System.out.println("Your CITY is.");
							System.out.println(LS[3]);
						}

					}

				}
			}

			if (F == true) {
				System.out.println("The details of specific person have been displayed");
			} else {
				System.out.println("\n Sorry! couln't find the details");
			}

		}

		catch (Exception e) {
			System.out.println("Error in customer class file Exception");
		}
	}

	public void viewAllMember()

	{
		try {

			Scanner fileReader = new Scanner(fileCustomer);

			while (fileReader.hasNextLine()) {
				String completeLine = fileReader.nextLine();
				String[] lineSeperation = completeLine.split(",");

				for (int c = 0; c < completeLine.length(); c++) {

					if (c == 0) {
						System.out.println("Member name is.");
						System.out.println(lineSeperation[0]);
					} else if (c == 1) {
						System.out.println("Member CNIC is.");
						System.out.println(lineSeperation[1]);
					} else if (c == 2) {
						System.out.println("Member AGE is.");
						System.out.println(lineSeperation[2]);
					} else if (c == 3) {
						System.out.println("Member City is.");
						System.out.println(lineSeperation[3]);
					}

				}

				System.out.println("\n\n The details have been displayed");

			}

		}

		catch (Exception e) {
			System.out.println("Error in customer class file Exception");
		}
	}

}