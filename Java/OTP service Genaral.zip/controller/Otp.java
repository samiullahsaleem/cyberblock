/*                 OTP service : Solutions
				   Tayyab Nasir
				   218-BSCS-2019
				   Section E2

				   There you will get to know about the Otp management scenarios
				   The classes include (Bank.java) (Otp.java) (Client.java) (Product.java) (MainClass.java) 
*/
package controller;
import java.util.Random;
import java.util.ArrayList;

public class Otp
{
    public String name;
    public int amount;
    public int AccountNumber;
    public int OtpNumber;
    public int a=0;
    ArrayList <Integer> O = new ArrayList <Integer>();
    ArrayList <Integer> A = new ArrayList <Integer>();
    Random rand = new Random();
    
    public Otp(int amount)
    {
        this.amount=amount;
        A.add(amount);
        a=a+amount;
    }
    public void setOtp(int OtpNumber)
    {
        this.OtpNumber=OtpNumber;
    }
    public void setAmount(int amount)
    {
        this.amount=amount;
    }
    public int getAmount()
    {
        return amount;
    }
    public void getTotalAmount()
    {
        System.out.println("Total amount is = "+a);
    }
    public int getOtp()
    {
        return OtpNumber;
    }
    public void otpGen()
    {
        int random = rand.nextInt(10000);
        addOtp(random);
    }
    public void addOtp(int o)
    {
        O.add(o);
    }
    public void addAmount(int am)
    {
        A.add(am);
        a=a+am;
    }
    public void OtpSol()
    {
        for (int i=0; i<5; i++)
        {
            otpGen();
        }

    }
    public int totalTransactions()
    {
        return (O.size());
    }
    public void displayOTP()
    {
        for (int i: O)
        {
            System.out.println("Otp of number "+O.indexOf(i)+" equals to "+i);
        }
    }
    public void displayAmounts()
    {
        for (int a: A)
        {
            System.out.println("The amount number is = "+a);
        }
    }
    public void searchOtp(int s1)
    {
        boolean x=false;
        for (int i: O)
        {
            if (i==s1)
            {
                x=true;
                break;
            }
            else
            {
                x=false;
            }
            
        }
        if (x=true)
            {
                System.out.println("Yes the otp is in this list");
            }
            else
            {
                System.out.println("The otp is not available in this arraylist");
            }
    }
    public void searchAmount(int s2)
    {
        boolean y=false;
        for (int l: A)
        {
            if (l==s2)
            {
                y=true;
                break;
            }
            else
            {
                y=false;
            }
        }
        if (y=true)
            {
                System.out.println("Amount is available in this list"); 
            }
            else
            {
                System.out.println("Specific amount is not available in list");
            }
    }
    public void removeOtp(int rem)
    {
        O.remove(rem);
    }
    public void DisplayAll()
    {
        for (int i=0; i<O.size(); i++)
        {
        	int pt1 = O.get(i);
        	int pt2 = A.get(i);
            System.out.println("The otp of "+pt1+" has amount = "+pt2);
        }
    }


}