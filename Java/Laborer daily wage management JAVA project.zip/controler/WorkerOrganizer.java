package controler;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.swing.JOptionPane;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.util.*;
public class WorkerOrganizer 
{

    // all the variables have be declared in different methods accordint to need
    ArrayList<Worker> worker=new ArrayList<>();
        // this method will add workers in arraylist
   public void add_Workers(Worker w) 
   {  
      
       worker.add(w);
       
       
   }
   // this method will write objects into array list
   public void write_Workers() throws FileNotFoundException,IOException,ClassNotFoundException
   {
       
        ObjectOutputStream write_workers=new ObjectOutputStream(new FileOutputStream("Database.txt"));
        write_workers.writeObject(worker);
        write_workers.close(); 
       

   }
   // this mthod will read data from file and store into array list
   @SuppressWarnings("unchecked")
   public void read_worker() throws FileNotFoundException,IOException,ClassNotFoundException
   { 
    ObjectInputStream read=new ObjectInputStream(new FileInputStream("DataBase.txt"));
     worker=(ArrayList<Worker>)read.readObject();
     read.close();
     
      
   }

    // this method will search worker and then print record of that worker
    public void search_worker() 
    
    {
      int result;  // will store the option of yes or no from the user
      do
      {  
        boolean flag=false;  // used for conditions
        String n;   // store the name of worker
        n=JOptionPane.showInputDialog("Enter the name of worker who you can find  ");
        for(Worker f:worker)
        {
            if(f.getName().equalsIgnoreCase(n))   // camparing name of worker annd after it print record
            {
                flag=true;
            f.display();
            }
        }
        if(flag==false)  // this condition will be true if name is not lies in the record
        {
        JOptionPane.showMessageDialog(null,"Sorry, we can't find "+n+" . Kindly, enter correct name");
       result=JOptionPane.showConfirmDialog(null,"Do you want to search worker again?");
        }
        else
        result=JOptionPane.showConfirmDialog(null,"Do you want to search worker again?");

    }while(result==JOptionPane.YES_OPTION);
        
    }
    // this method will take name from user and the  remove that worker from the record
   public void remove_worker()
   {
       int result;
       do
       {
    boolean flag=false;
    String n;
    n=JOptionPane.showInputDialog("Enter the name of worker who you can delete : ");
    Iterator<Worker> itr=worker.iterator();
    while(itr.hasNext())
    {
        if(itr.next().getName().equalsIgnoreCase(n)) //comparing
        {
            flag=true;
        itr.remove();
        }
    }
    if(flag==false)
    {
    JOptionPane.showMessageDialog(null,"Sorry, we can't find "+n+" . Kindly, enter correct name");
    result=JOptionPane.showConfirmDialog(null,"Do you want to remove worker again?");
    }
   else
   {
   JOptionPane.showMessageDialog(null,n+" has been deleted from the record");
   result=JOptionPane.showConfirmDialog(null,"Do you want to remove another worker again?");
   }
   }while(result==JOptionPane.YES_OPTION);
}
      // this method will print name of all workers
   public void print_name_of_all_workers() 
   {
       System.out.println("The names of all workers ");
       for(Worker f:worker)
       {
        JOptionPane.showMessageDialog(null,""+f.getName());
       }
   }
    // this method will tell you about totao number of workers
   public void size_of_workers() 
   {

    JOptionPane.showMessageDialog(null,"The total workers are : "+worker.size());
   }
   // this method will change the name ,phone number adn waging of the worker
   public void Edit_worker() 
   {
       boolean flag=false; // it will be used for condition
       String name,new_Phone_number,string_wagString;  // store the data from the user
       int result1,result2,result3;  // will be used for options from the user like Yes 
       int waging; 
       String n;
       {
           int res;
       n=JOptionPane.showInputDialog("Enter the name of worker who you can edit ");
       for(Worker f:worker)
       {
           if(f.getName().equalsIgnoreCase(n))
           {
               flag=true;
               f.display();
                result1=JOptionPane.showConfirmDialog(null,"Do you want to change the name of worker?");
             if(result1==JOptionPane.YES_OPTION)
               {
               name=JOptionPane.showInputDialog("Enter the new name of worker");
               f.setName(name);
               }
               result2=JOptionPane.showConfirmDialog(null,"Do you want to change the phone number  of worker?");
               if(result2==JOptionPane.YES_OPTION)
               {
                   new_Phone_number=JOptionPane.showInputDialog(null,"Enter the new Phone number of workee ");
                   f.setPhone_number(new_Phone_number);

               }
               result3=JOptionPane.showConfirmDialog(null,"Do you want to change the waging of worker?");
               if(result3==JOptionPane.YES_OPTION)
               {
                try{
                    string_wagString=JOptionPane.showInputDialog(null,"\nEtner new waging of worker ");
                    waging=Integer.parseInt(string_wagString);
                    f.setWaging(waging);
                    }catch(NumberFormatException e)
                    {
                        string_wagString=JOptionPane.showInputDialog(null,"\nYou should type integer value for waging of worker \nNow Enter again waging of worker\n Etner waging of worker ");
                        waging=Integer.parseInt(string_wagString);
                        f.setWaging(waging);
                    }
            }
         }

       }
       if(flag==false) // this condition will true when there is error of not founding of worker 
       {
        JOptionPane.showMessageDialog(null,"Sorry, we can't find "+n+" . Kindly, enter correct name");
    res=JOptionPane.showConfirmDialog(null,"Do you want to search again for editing worker?");
    if(res==JOptionPane.YES_OPTION)
    Edit_worker();
        
       }
    
   
    }
}
// this method will sum of rupees of all salaries of workers
public void sum_of_Salaries_of_all_workers() 
{
    
    int sum_of_rupees=0;
    for(Worker f:worker)
    {
        sum_of_rupees=sum_of_rupees+f.getSalary();
    }
    JOptionPane.showMessageDialog(null,"\n The total rupees of salaries of all workers are    :    "+sum_of_rupees);
}


}


