package controler;
abstract class Clear_record extends Advance_rupees
{
    //So, it is an abstract class therefore the method of it class will be used its sub class
    //That's why there is any type of variables all the variables  will be used it's sub class
    public Clear_record()
    {
       // constructer
    }
    abstract void clear_record(String name);  // overide meethod of abstracter class
}