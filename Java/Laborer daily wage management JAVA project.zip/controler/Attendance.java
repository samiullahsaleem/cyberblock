package controler;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.lang.model.util.ElementScanner6;
import javax.swing.JOptionPane;

public class Attendance extends WorkerOrganizer
{
public String attendance;  // will store the attendance of worker which will be taken from user
public LocalDate date;    // will store date of today
public String name;
boolean flag=false;  // flag variableswill be used for conditions in the class
public boolean main_flag=false;
//others variables will be used in the methods according to the need

//  this method will take name from user and check that is that name lies in the record
public void check_name()
{
    LocalDate date2=LocalDate.now();
    int check_yes_or_no; // will store the option from worker
    boolean falg_1=false;
    name=JOptionPane.showInputDialog("\nToday date is  :  "+date2+"\nEnter the name of worker for set attendance of him");
    for(Worker f:super.worker)
    {
        if(f.getName().equalsIgnoreCase(name))
        falg_1=true;

    }
    if(falg_1==false)
    {
    check_yes_or_no=JOptionPane.showConfirmDialog(null,"\nYou did not enter correct name \nKindly, Click on enter for entering again name");
        if(check_yes_or_no==JOptionPane.YES_OPTION)
        check_name();  // if name is not lies in the record then method will be called again
}
    
}
// this method will take attendance of every worker and the store attendance in the record of worker
public void setAttendance()
{
    Format dateFormat=new SimpleDateFormat("EEE");
    String res= dateFormat.format(new Date());  // day name
    String day_name;
    // comparing with the name of day and then assign complete name of day to day_name variable 
    if(res.equalsIgnoreCase("Mon"))
    {
        day_name="Monday";
    }
    else if(res.equalsIgnoreCase("Tue"))
    {
        day_name="Tuesday";
    }
    else if(res.equalsIgnoreCase("Thu"))
    {
        day_name="Thursday";
    }
    else if(res.equalsIgnoreCase("Wed"))
    {
        day_name="Wednesday";
    }
    else if(res.equalsIgnoreCase("Fri"))
    {
        day_name="Friday";
    }
    else if(res.equalsIgnoreCase("Sat"))
    {
        day_name="Saturday";
    }
    else
    {
        day_name="Sunday";
    }
    date=LocalDate.now();
    JOptionPane.showMessageDialog(null," \nToday date is : "+date+"        Day name is  :  "+day_name+"\n Now take attendance of every worker ");
    for(Worker f:super.worker)
    { 
        int result=0; // this var will store the option of yes or no from the user
        do{
        
        {
        attendance=JOptionPane.showInputDialog(null,"\nName is : "+f.getName()+"\nFather name is : "+f.getFather_name()+"\n\nEnter \"P\" if he is present\nEnter \"A\" if he is not Present\nEnter \" Half \" if he is present in half days ");
        
        if(attendance.equalsIgnoreCase("P"))
        {
        
            f.setAttendance("P"); // stroing the "P" because worker is present 
            f.setDate(date);  // for storing date
            f.setDay_name(day_name);    //for storing day name
            break;
        }
        else if(attendance.equalsIgnoreCase("A"))
        {
            
f.setAttendance("A");// stroing the "A" because worker is Aphsent
f.setDate(date);
f.setDay_name(day_name);   //for storing day name
break;

        }
        else if(attendance.equalsIgnoreCase("half"))
        {
            f.setAttendance("Half");  // stroing the "half" because worker did work in half day
            f.setDate(date);
            f.setDay_name(day_name);    //for storing day name
            break;
        }
        else    // show error if user did not enter correct character for attendance
        {
            result=JOptionPane.showConfirmDialog(null,"\nYou did not enter correct charachter for attendance\nEnter \"P\" if worker is present\nEnter \"A\" if worker is not present\nClick \"Yes\" for setting attendance of same worker");
        }
    }

    }while(result==JOptionPane.YES_OPTION);
}
    
}
//  this method will set attendance of specifics worker and this method will run when attendance of that worker will be taken firs
public  boolean setAttendance_of_specific_worker()
{

    int indaex=0;  // this will be indax number of  attendance type arraylist in which atendance user set attendance of worker firs
    LocalDate date1=null;
    String string_date;
  LocalDate  date2=LocalDate.now();
check_name();  // this method wil take name of worker whose attendance you want to set and will check name is lies in the record?
for(Worker f:super.worker)
    {
    
        if(f.getName().equalsIgnoreCase(name))
        {
            
            
            {
                try {
                    string_date=JOptionPane.showInputDialog("\nEnter the date of which date you want to attendance according to the following date formate\nYou must follow the following date formate . Otherwise error will be generate \n"+date2);
                    date1=LocalDate.parse(string_date); 
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null,"kindly emter date according to the formate \nNow enter again name of the worker and set hi attendance");
                    setAttendance_of_specific_worker();
                }
           
           
             // contverting antered date wich too from user into type of localdae
           {
           for(LocalDate f2:f.date)
           {
               if(f2.equals(date1))
               {
                   main_flag=true;  // store true because date is lies in the record
                   int result=0;    // will store the option of yes no 
                   do{
                       flag=true;
        attendance=JOptionPane.showInputDialog(null,"\nName is : "+f.getName()+"\nFather name is : "+f.getFather_name()+"\n\nEnter \"P\" if he was present\nEnter \"A\" if he was not Present\nEnter \"half\" if he done worke in half day");
        if(attendance.equalsIgnoreCase("p"))
        {
            
            f.attendance.remove(indaex);  // removing the attendance which was takenn first from the record
            f.attendance.add(indaex, "P");  // and the setting the attendace in the same indaex
            break;
        }
        else if(attendance.equalsIgnoreCase("A"))
        {
            
            f.attendance.remove(indaex);
f.attendance.add(indaex,"A");
break;
        }
        else if(attendance.equalsIgnoreCase("half"))
        {
            
            f.attendance.remove(indaex);
            f.attendance.add(indaex,"Half");
            
            break;
        }
        else
        {
            result=JOptionPane.showConfirmDialog(null,"\nYou did not enter correct charachter for attendance\nEnter \"P\" if worker was present\nEnter \"A\" if worker was not present\nClick \"Yes\" for taking attendance of same worker again" );


        }
    }while(result==JOptionPane.YES_OPTION);
    }

    indaex++; // folloeing the indax
    }
}
    
}
    }

    }
    return main_flag;  // return flag , flag will be false if date is not lies first in the record and flag will be false if date is not lies

}

}
