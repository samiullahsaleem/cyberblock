package controler;
import java.awt.*;
import javax.swing.JOptionPane;

public class Advance_rupees extends Attendance
{
    
    // declaring all the variables which we need to declare 
    public int advance_rupees;
    public String string_advance_rupees;  
    public String name;
    int result;  // use for storing the option of user like yes 
    boolean flag=false;
    public void set_addvance_rupees()
    { 
        name=JOptionPane.showInputDialog("\nEnter the name of worker who took advance rupees");
        
        for(Worker f:super.worker)
        {
            if(f.getName().equalsIgnoreCase(name))
            {
                
                f.display();
                string_advance_rupees=JOptionPane.showInputDialog("Enter the advance rupees of the worker which he took addvance");
                advance_rupees=Integer.parseInt(string_advance_rupees);
                 // converting string to int
                f.setAddvance_rupees(advance_rupees);  // storeing the advance rupees 
                flag=true;
            }
        }
        if(flag==false)
        {
             // showing error of wrong ener name
    JOptionPane.showMessageDialog(null,"\nYou did not enter correct name\nNow, Enter correct name again");    
     set_addvance_rupees();   
}
     
    }
    
    
}