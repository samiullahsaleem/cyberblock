package controler;
import javax.swing.JOptionPane;

public class Print_Record extends Clear_record
{
    // the declaration of all the variables which are required for checking conditions and storeing date in the following
    private int i;
    private int j;
    private int result,result1,result3,result4;  // thses are the varialbes for responsing input are used like yes or no
    private String name;
    private boolean flag=false;  // for the implementing the condition
// this method will clear the array list of date and time
    public void clear_record(String name)
    {
        for(Worker f:super.worker)
        {
            if(f.getName().equalsIgnoreCase(name))  // comparing with the name for deleting the record
            {
                // clearing array lists
                f.attendance.clear();
                f.date.clear();
                f.day_name.clear();
                
                
            }
        }
    }
    // this method will take the input from user of worker and then display the record of that worker
    public void print_record_of_specifics_worker()
    { 
          // asking the name of worker for displaying his record
        name=JOptionPane.showInputDialog(null, "\nEnter the name of worker for getting his record  :  ");  
        for(Worker f:super.worker)
        {
            if(f.getName().equalsIgnoreCase(name))   //comparing the name of worker from the arraylist of workers
            {
            f.display();  // calling the method for display the general record of the worker
            for(i=0;i<f.attendance.size();i++)  // this loop is used of printing the record of attendance of worker
            {
            JOptionPane.showMessageDialog(null,"\nThe days of working :\n Date  is  :  "+f.date.get(i)+"           Day name is :   "+f.day_name.get(i)+"        Attendance is  :  "+f.attendance.get(i));
 
            }
            result1=JOptionPane.showConfirmDialog(null,"\nTotal Presents in working days  :  "+f.getPresent()+"\nTotal Aphsent in working days  :  "+f.getAphsent()+"\nTotal Half attendance is  :  "+f.get_no_of_day_of_half_working()+"\nWaging of "+f.getName()+" is  :  "+f.getWaging()+"\n\nTotal salary of "+f.getName()+" is  :  "+f.getSalary()+"\n\nTook Advance rupees are  :  "+f.getAddvance_rupees()+"\nDo you want to cut advance rupees from salary of worker?"+"\n");
            if(result1==JOptionPane.YES_OPTION)
            {
                // this method will cut the advance rupees from the salary and disply remaing salary after cutting advance rupees
                    
                f.cut_addvance_rupees_from_salary();
                JOptionPane.showMessageDialog(null,"\nAfter cutting advance rupees\n\nSalary is  :  "+f.get_salalry_after_cutting_addvance_rupees()+"\n\n");
                if(f.get_salalry_after_cutting_addvance_rupees()<0)
                f.setAddvance_rupees(Math.abs(f.get_salalry_after_cutting_addvance_rupees()));  // if salary of worker is less than the advance rupees then remaing rupees is set as advance rupees
                if(f.get_salalry_after_cutting_addvance_rupees()>=0)  
                f.setAddvance_rupees(0); // if after cutting advance rupees salaary comes as 0 or moe than one then set advance rupees is zero becuse it will be cut from the salary
                
            }
            result3=JOptionPane.showInternalConfirmDialog(null, "Do you want to delete record of worker else name,father name,phone number and wand waging of worker");
            if(result3==JOptionPane.YES_OPTION)
            {
                
                clear_record(f.getName());  // this method will cut the attendance of worker if user wants
            }
            flag=true;
        }
        }
        if(flag==false)
        {
            // if name is not lies in the record then shows error
         JOptionPane.showMessageDialog(null,"\nYou did not enter correct name of workers \nKindly,Enter again name of worker for getting his record");
        }
    }
    
    // this method will print the record of all workers
    public void print_Record_of_Every_worker()
    {
        for(Worker f:super.worker)
        {
            f.display();// calling the method for displaying the general record of worker
            for(j=0;j<f.attendance.size();j++)
            {
                
            JOptionPane.showMessageDialog(null,"\nThe days of working :\n Date  is  :  "+f.date.get(j)+"         Day name is :  "+f.day_name.get(j)+"        Attendance is  :  "+f.attendance.get(j));

            }
            result=JOptionPane.showConfirmDialog(null,"\nTotal Presents in working days  :  "+f.getPresent()+"\nTotal Aphsent in working days  :  "+f.getAphsent()+"\nTotal Half attendance is  :  "+f.get_no_of_day_of_half_working()+"\nWaging of "+f.getName()+" is  :  "+f.getWaging()+"\n\nTotal salary of "+f.getName()+" is  :  "+f.getSalary()+"\n\nTook Advance rupees are  :  "+f.getAddvance_rupees()+"\nDo you want to cut advance rupees from salary of worker?"+"\n");
            if(result==JOptionPane.YES_OPTION)
            {
                // this method will cut the advance rupees from the salary and disply remaing salary after cutting advance rupees
                f.cut_addvance_rupees_from_salary();
                JOptionPane.showMessageDialog(null,"\nAfter cutting advance rupees\n\nSalary is  :  "+f.get_salalry_after_cutting_addvance_rupees()+"\n\n");
                if(f.get_salalry_after_cutting_addvance_rupees()<=0)
                f.setAddvance_rupees(Math.abs(f.get_salalry_after_cutting_addvance_rupees())); // if salary of worker is less than the advance rupees then remaing rupees is set as advance rupees
                if(f.get_salalry_after_cutting_addvance_rupees()>=0)
                f.setAddvance_rupees(0);
                // if after cutting advance rupees salaary comes as 0 or moe than one then set advance rupees is zero becuse it will be cut from the salary
            }
            result4=JOptionPane.showInternalConfirmDialog(null, "Do you want to delete record of worker else name,father name,phone number and wand waging of worker");
            if(result4==JOptionPane.YES_OPTION)
            {
            
                clear_record(f.getName()); // calling the method for deleting record of attendance
            }
           
        }
    }
}