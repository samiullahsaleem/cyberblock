



you should get different fuctionality from menue according to the instructions on menue
you shuold not enter on the place of name where you may enter name of worker as without write press enter otherwise it will be saved as worker
all the erros will be show 
dont use cancel option at any time
it is compulsory to set attendance of any worker that first you may took attendance of any worker whose want to set attendance
you shuld enter date according to the format which will be given on the screen
when you will delete record of the worker the the salary of that worker will be cut from the total salariesy of worker
take attendance of workers in only one time in a day 
always give data in the integer form as a waging of worker