import controler.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Main implements ask_about_worker_information_from_user
{
    public String ask_name_from_user()
    {
        String name;
        name=JOptionPane.showInputDialog(null,"\n Enter name of worker ");
      return name;
    }
    public String ask_father_name_from_user()
    {
        String father_name;
        father_name=JOptionPane.showInputDialog(null, "\nEnter father name of worker ");
        return father_name;
    }
    public String ask_phone_number_from_user()
    {
        String phone_number;
        phone_number=JOptionPane.showInputDialog(null, "\nEnter phone number of worker" );
        return phone_number;
    }
    public int ask_waging_of_worker_from_user()            
    {
        int result;
        int waging=0;
                    String string_wagString;
            // user can enter enter waging in string form that's way exception ihas been used
        try{
            string_wagString=JOptionPane.showInputDialog(null,"\nEtner waging of worker ");
            waging=Integer.parseInt(string_wagString);
            }catch(NumberFormatException e)
            {
                result=JOptionPane.showConfirmDialog(null,"\nYou should type integer value for waging of worker \nNow Enter \" Yes \" for entring waging again ");
                if(result==JOptionPane.YES_OPTION)
                ask_waging_of_worker_from_user();
            }
            return waging;
    }
    public static void main (String args[]) throws FileNotFoundException,IOException,ClassNotFoundException
    {
   
      //  store_workers_in_files obj1=new store_workers_in_files();
      Print_Record obj=new Print_Record();//his is the class by which we can access data of all the 
        try {
            obj.read_worker();
            
        } catch (Exception e)
         {
            // when file of data base is empty and if in this condition we call method of red-Workers then there is exception
            // so with the help of exception we ressolve this issue
        }
        try{
         // storing data from files to array list
        int result;  // will stoe the option
        int iterate=1; // store the option of menue
         String user_requirement;  
         boolean flag,flag2;  // these will be used for different classes
         boolean flag3=false;
         while(iterate==1)
         {
          // printing manue    
          
            user_requirement=JOptionPane.showInputDialog(null,"\nWORKERS SALALRY MANAGEMENT SYSTEM\n\nType \" 1 \" to Add worker in record               \nType \" 2 \" to search worekr \nType \" 3 \" to remove worker from record\nType \" 4 \" for Editing Spesific worker\nType \" 5 \" to know number of workers from a record \nType \" 6 \" to print names of all workers\nType \" 7 \" to take attendance of all workers\nType \" 8 \" to set attendance of spesific worker\nType \" 9 \" to set attendance of half day working of spesifics worker\nType \" 10 \" to Addvance rupees of worker \nType \" 11 \" to print record of all workers\nType \" 12 \" to print record of specifics worker\nType \" 13 \" to total of salaries of all worker \nType \" 14 \" to   Exit","Menue",JOptionPane.INFORMATION_MESSAGE);
            
            
                if(user_requirement.equalsIgnoreCase("1"))
                {
                    Main obj1=new Main();  //declararion of this class
                    
                    // these variables will be used to store data of the record like name
                    String name=obj1.ask_name_from_user();
                    String father_name=obj1.ask_father_name_from_user();
                    String phone_number=obj1.ask_phone_number_from_user();
                    int waging=obj1.ask_waging_of_worker_from_user();
                    
                
                    obj.add_Workers(new Worker(name,father_name,phone_number, waging)); // adding the worker and its data in arraylist
                   
                
                }
                else if(user_requirement.equalsIgnoreCase("2"))
                { 
                    obj.search_worker();  // will search and then disply
                }
                else if(user_requirement.equalsIgnoreCase("3"))
                {
                    obj.remove_worker();  // will remove the worker from the record
                }
                else if(user_requirement.equalsIgnoreCase("4"))
                {
                    obj.Edit_worker();  // will change waging and name and phone number of worker
                }
                else if(user_requirement.equalsIgnoreCase("5"))
                {
                    obj.size_of_workers();
                }
                else if(user_requirement.equalsIgnoreCase("6"))
                {
                    obj.print_name_of_all_workers();
                }
                else if(user_requirement.equalsIgnoreCase("7"))
                {
                    // there have been makeup set and the set will allow for attendance in only one tim in the days
                   if((flag3==false))
                   {
                    obj.setAttendance();
                    flag3=true;
                   }
                   else
                   { 
                       // show message if trying to take attendance for 2nd time in the same day
                    JOptionPane.showMessageDialog(null,"\nYou can just attendance in only one time in a day\nif you want to attendance of spesifics worker then selet option of it from menue \n");

                   }
                }
                else if(user_requirement.equalsIgnoreCase("8"))
                {
                    flag=obj.setAttendance_of_specific_worker();  // set attnedance of spesifics worker
                    if(flag==false)
                    { // showing error of date of entering wrong
                        JOptionPane.showMessageDialog(null,"\nYou did not enter correct date for setting attendance\nKindly , Enter the correct\nNow go to the manue and set attendance of worker again  ");
                        
                    }
                }
                else if(user_requirement.equalsIgnoreCase("9"))
                {
                    flag2=obj.setAttendance_of_specific_worker();
                    if(flag2==false)
                    {// showing error of date of entering wrong

                        JOptionPane.showMessageDialog(null,"\nYou did not enter correct date for setting attendance\nKindly , Enter the correct \nNow got to he manue and set attendance of worker again ");
                        
                    }
                }
                else if(user_requirement.equalsIgnoreCase("10"))
                {
                    obj.set_addvance_rupees();  
                }
                else if(user_requirement.equalsIgnoreCase("11"))
                {
                    obj.print_Record_of_Every_worker();    // will be shown record of all the workers
                }
                else if(user_requirement.equalsIgnoreCase("12"))
                {
                    obj.print_record_of_specifics_worker();
                }
                else if(user_requirement.equalsIgnoreCase("13"))
                {
                    obj.sum_of_Salaries_of_all_workers();  // will tel about to the sum of salaries of all the workers
                }
                else if(user_requirement.equalsIgnoreCase("14"))
                {
                    obj.write_Workers();
                    iterate=0;
                }
                
               else{
                   result=JOptionPane.showConfirmDialog(null, "\nYou did not enter correct number for getting functionality\nKindly, Enter correct number\nDo you want to go to menue again?");
               
               }
            

            }
            
        }
        catch(Exception e)
            {
                //some time user do cancel in from manue then in this condition atleast data should be stored
                obj.write_Workers();
            }
        }
    }
    